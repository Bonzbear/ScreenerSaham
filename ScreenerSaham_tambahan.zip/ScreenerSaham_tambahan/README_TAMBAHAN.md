# Tambahan untuk repo ScreenerSaham

Isi zip ini:
- pages/Screener_Baru.py   -> halaman baru (otomatis muncul di sidebar aplikasi)
- screener_baru/           -> mesin screener, backtest, data (folder baru, tidak menyentuh file lama)

Langkah (lewat web GitHub):
1. Buat cadangan: di repo, klik dropdown "main" -> ketik "versi-lama" -> "Create branch".
2. Kembali ke branch main. Di root repo: Add file -> Upload files -> seret folder `screener_baru` -> Commit.
3. Buka folder `pages` -> Add file -> Upload files -> pilih Screener_Baru.py -> Commit.
4. Edit requirements.txt (ikon pensil): tambahkan baris `pyarrow` dan pastikan ada `yfinance`, `pandas`, `requests`.
5. Streamlit Cloud akan deploy ulang otomatis. Buka halaman "Screener Baru" -> Perbarui data Yahoo.
6. Telegram: Streamlit Cloud -> Settings -> Secrets, isi:
   TELEGRAM_TOKEN = "..."
   TELEGRAM_CHAT_ID = "..."
